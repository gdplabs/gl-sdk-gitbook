import os
from dotenv import load_dotenv
from gllm_generation.reference_formatter import SimilarityBasedReferenceFormatter
from gllm_inference.em_invoker.openai_em_invoker import OpenAIEMInvoker

load_dotenv()

em_invoker = OpenAIEMInvoker(
    model_name=os.getenv("EMBEDDING_MODEL"),
    api_key=os.getenv("OPENAI_API_KEY"),
)

reference_formatter = SimilarityBasedReferenceFormatter(
    em_invoker=em_invoker, threshold=0.5, stringify=False
)
