from gllm_misc.context_manipulator import Repacker

repacker = Repacker(mode="context")
