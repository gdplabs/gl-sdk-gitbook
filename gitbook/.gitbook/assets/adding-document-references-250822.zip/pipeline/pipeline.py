import asyncio
from gllm_pipeline.steps import bundle, step

from modules.repacker import repacker
from modules.response_synthesizer import response_synthesizer
from modules.retriever import retriever
from modules.reference_formatter import reference_formatter

retriever_step = step(
    retriever,
    {"query": "user_query"},
    "chunks",
    {"top_k": "top_k"},
)

repacker_step = step(
    repacker,
    {"chunks": "chunks"},  # input variables
    "context",  # output variable
)

bundler_step = bundle(
    ["context"],
    "response_synthesis_bundle",
)

response_synthesizer_step = step(
    response_synthesizer,
    {"query": "user_query", "state_variables": "response_synthesis_bundle"},
    "response",
)

reference_formatter_step = step(
    reference_formatter,
    {
        "response": "response",
        "chunks": "chunks",
        "event_emitter": "event_emitter",
    },
    "references",
)

e2e_pipeline = retriever_step | repacker_step | bundler_step | response_synthesizer_step | reference_formatter_step

state = {
    "user_query": "Give me nocturnal creatures from the dataset",  # Replace with your actual query
}

config = {
    "top_k": 5,
    "debug": True,  # Set to True to look at the pipeline execution flow
}

result = asyncio.run(e2e_pipeline.invoke(state, config))
print(f"Pipeline result: {result['response']}")
print(f"References: {result['references']}")
