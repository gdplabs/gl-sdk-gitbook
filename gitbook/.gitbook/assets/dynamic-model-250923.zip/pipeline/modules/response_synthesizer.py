"""Response synthesis module for the dynamic model pipeline.

This module handles the dynamic creation of response synthesizers with different models.
"""
import os

from dotenv import load_dotenv
from gllm_generation.response_synthesizer import ResponseSynthesizer
from gllm_inference.builder import build_lm_request_processor

load_dotenv()


def build_response_synthesizer(model_id: str) -> ResponseSynthesizer:
    """Build response synthesizer with dynamic model selection.

    Args:
        model_id (str): The model identifier to use for the LM request processor.

    Returns:
        ResponseSynthesizer: Synthesizer configured with SYSTEM_PROMPT and USER_PROMPT.
    """
    SYSTEM_PROMPT = """
    - Use only the information provided in the context below to answer the user's question.
    You may infer simple, logical conclusions based on the context, but do not introduce
    new facts or external knowledge.
    - You may suggest or summarize the options listed in the context if the question asks
    for recommendations, ideas, or what to do.
    - If the context does not contain enough information to answer the user's question, respond with:
    "Sorry, I don't have enough information to answer that."

    Context:
    {context}
    """
    USER_PROMPT = "Question: {query}"

    lm_request_processor = build_lm_request_processor(
        model_id=model_id,
        credentials=os.environ["OPENAI_API_KEY"],
        system_template=SYSTEM_PROMPT,
        user_template=USER_PROMPT,
    )
    response_synthesizer = ResponseSynthesizer.stuff(
        lm_request_processor=lm_request_processor,
        streamable=True,
    )

    return response_synthesizer
