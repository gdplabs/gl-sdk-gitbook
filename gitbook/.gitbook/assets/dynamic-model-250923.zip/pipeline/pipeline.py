"""Dynamic model RAG pipeline implementation.

This module demonstrates a RAG pipeline that can dynamically select different language models.
"""
import asyncio

from gllm_pipeline.pipeline import Pipeline
from gllm_pipeline.steps import step

from modules.response_synthesizer import build_response_synthesizer
from modules.retriever import retriever


def build_pipeline(model_id: str) -> Pipeline:
    """Build the end-to-end pipeline.

    Args:
        model_id (str): Model identifier used to build the response synthesizer.

    Returns:
        Any: A composed pipeline with .invoke(state, config) coroutine method.
    """
    # The following steps stay the same
    retriever_step = step(
        component=retriever,
        input_state_map={"query": "user_query"},
        output_state="chunks",
        runtime_config_map={"top_k": "top_k"}
    )

    # Use the response synthesizer builder
    response_synthesizer = build_response_synthesizer(model_id)
    response_synthesizer_step = step(
        component=response_synthesizer,
        input_state_map={
            "query": "user_query",
            "chunks": "chunks",
            "kwargs": "chunks",
            "event_emitter": "event_emitter"
        },
        output_state="response"
    )

    return retriever_step | response_synthesizer_step

if __name__ == "__main__":
    model_id = "openai/gpt-4.1-nano"  # Change this to whatever you want
    e2e_pipeline = build_pipeline(model_id)
    state = {
        "user_query": "Give me nocturnal creature from the dataset",  # Replace with your actual query
        "event_emitter": None,
    }

    config = {
        "top_k": 5,
        "debug": True,  # Set to True to look at the pipeline execution flow
    }

    result = asyncio.run(e2e_pipeline.invoke(state, config))
    print(f"Response: {result['response']}")

