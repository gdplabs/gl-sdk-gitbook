import os

from dotenv import load_dotenv
from gllm_generation.response_synthesizer import StuffResponseSynthesizer
from gllm_inference.builder import build_lm_request_processor

load_dotenv()

SYSTEM_PROMPT = """
You are a helpful assistant that recommends.

Use knowledge base is {use_knowledge_base}.

When user decided to use knowledge base, you should:
- Use only the information provided in the context below to answer the user's question. You may infer simple, logical conclusions based on the context, but do not introduce new facts or external knowledge.
- You may suggest or summarize the options listed in the context if the question asks for recommendations, ideas, or what to do.
- If the context does not contain enough information to answer the user's question, respond with:
"Sorry, I don't have enough information to answer that."

When user decided to not use knowledge base, you should answer the user's question based on your general knowledge.

Context:
{context}
"""
USER_PROMPT = "Question: {query}"

lm_request_processor = build_lm_request_processor(
    model_id=os.environ["LANGUAGE_MODEL"],
    credentials=os.environ["OPENAI_API_KEY"],
    system_template=SYSTEM_PROMPT,
    user_template=USER_PROMPT,
)

response_synthesizer = StuffResponseSynthesizer(lm_request_processor=lm_request_processor)
