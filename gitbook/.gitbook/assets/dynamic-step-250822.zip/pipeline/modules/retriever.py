import os

from dotenv import load_dotenv
from gllm_datastore.vector_data_store import ElasticsearchVectorDataStore
from gllm_inference.em_invoker.openai_em_invoker import OpenAIEMInvoker
from gllm_retrieval.retriever.vector_retriever import BasicVectorRetriever

load_dotenv()


embedding_model = OpenAIEMInvoker(
    model_name=os.getenv("EMBEDDING_MODEL"),
    api_key=os.getenv("OPENAI_API_KEY"),
)

data_store = ElasticsearchVectorDataStore(
    index_name=os.getenv("INDEX_NAME"),
    embedding=embedding_model,
    url=os.getenv("ELASTICSEARCH_URL"),
)

retriever = BasicVectorRetriever(data_store)
