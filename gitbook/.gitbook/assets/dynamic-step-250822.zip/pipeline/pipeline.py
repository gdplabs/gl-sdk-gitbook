"""Module for RAG Pipeline.

This pipeline retrieves relevant chunks of information based on a user query,
repackages them into a context, and synthesizes a response using a language model.

Authors:
    Delfia Nur Anrianti Putri (delfia.n.a.putri@gdplabs.id)

References:
    [1] GLAIR Gen AI AIE Onboarding document
"""

import asyncio
from gllm_pipeline.pipeline.pipeline import Pipeline
from gllm_pipeline.pipeline.states import RAGState
from gllm_pipeline.steps import bundle, step, toggle

from modules.repacker import repacker
from modules.response_synthesizer import response_synthesizer
from modules.retriever import retriever

class ToggleState(RAGState):
    use_knowledge_base: bool

retriever_step = step(
    retriever,
    {"query": "user_query"},
    "chunks",
    {"top_k": "top_k"},
)
repacker_step = step(
    repacker,
    {"chunks": "chunks"},  # input variables
    "context",  # output variable
)
bundler_step = bundle(
    ["context", "use_knowledge_base"],
    "response_synthesis_bundle",
)
response_synthesizer_step = step(
    response_synthesizer,
    {"query": "user_query", "state_variables": "response_synthesis_bundle"},
    "response",
)

knowledge_base_toggle_step = toggle(
    condition=lambda x: x["use_knowledge_base"],
    if_branch=[retriever_step, repacker_step],  # Both steps together
)

e2e_pipeline_with_knowledge_base_toggle = knowledge_base_toggle_step | bundler_step | response_synthesizer_step
e2e_pipeline_with_knowledge_base_toggle.state_type = ToggleState

# Configure the state and config for direct pipeline invocation
state = {
    "user_query": "Give me nocturnal creatures",  # Replace with your actual query
    "context": "",
    "use_knowledge_base": True,
}

config = {
    "top_k": 5,
    "debug": True,  # Set to True to look at the pipeline execution flow
}

result = asyncio.run(e2e_pipeline_with_knowledge_base_toggle.invoke(state, config))
print(f"Pipeline result: {result}")
