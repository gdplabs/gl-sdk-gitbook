import sys
mode = "gl-sdk"
sys.path.insert(0, "/home/delfia-n-a-putri/Documents/Work/GEN_AI/"+mode+"/libs/gllm-inference")
sys.path.insert(0, "/home/delfia-n-a-putri/Documents/Work/GEN_AI/"+mode+"/libs/gllm-pipeline")
sys.path.insert(0, "/home/delfia-n-a-putri/Documents/Work/GEN_AI/"+mode+"/libs/gllm-misc")
sys.path.insert(0, "/home/delfia-n-a-putri/Documents/Work/GEN_AI/"+mode+"/libs/gllm-generation")

########################################################################################################

import asyncio

from gllm_inference.lm_invoker import OpenAILMInvoker
from gllm_generation.response_synthesizer import StuffResponseSynthesizer
from gllm_inference.request_processor import LMRequestProcessor
from gllm_inference.prompt_builder import PromptBuilder

lm_invoker = OpenAILMInvoker(model_name="gpt-4o-mini")

system_template = """You are a helpful assistant that provides accurate and informative answers to general knowledge questions.
    Be concise but thorough in your responses."""

prompt_builder = PromptBuilder(
    system_template=system_template,
    user_template="Question: {query}",
)

general_query_handler = StuffResponseSynthesizer(
    LMRequestProcessor(
        lm_invoker=lm_invoker,
        prompt_builder=prompt_builder,
    )
)