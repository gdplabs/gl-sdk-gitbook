"""Module to repack the context for the response synthesizer.

Authors:
    Delfia Nur Anrianti Putri (delfia.n.a.putri@gdplabs.id)

References:
    [1] GLAIR Gen AI AIE Onboarding document
"""

from gllm_misc.context_manipulator import Repacker

repacker = Repacker(mode="context")
