import sys
mode = "gl-sdk"
sys.path.insert(0, "/home/delfia-n-a-putri/Documents/Work/GEN_AI/"+mode+"/libs/gllm-inference")
sys.path.insert(0, "/home/delfia-n-a-putri/Documents/Work/GEN_AI/"+mode+"/libs/gllm-pipeline")
sys.path.insert(0, "/home/delfia-n-a-putri/Documents/Work/GEN_AI/"+mode+"/libs/gllm-misc")
sys.path.insert(0, "/home/delfia-n-a-putri/Documents/Work/GEN_AI/"+mode+"/libs/gllm-generation")

########################################################################################################
import os
import json
from dotenv import load_dotenv

from gllm_misc.router.similarity_based_router import SimilarityBasedRouter
from gllm_inference.em_invoker import OpenAIEMInvoker

load_dotenv()

em_invoker_openai = OpenAIEMInvoker(
    api_key=os.environ["OPENAI_API_KEY"],
    model_name="text-embedding-3-small",
)

# load route examples from json file
with open("route_examples.json", "r", encoding="utf-8") as f:
    route_examples = json.load(f)

def semantic_router_component():

    # Define route examples for different categories
    similarity_router = SimilarityBasedRouter(
        em_invoker=em_invoker_openai,
        route_examples=route_examples,
        default_route="general",
        similarity_threshold=0.6
    )

    return similarity_router