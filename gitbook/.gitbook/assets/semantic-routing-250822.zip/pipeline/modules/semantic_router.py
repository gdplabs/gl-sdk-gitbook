import os
import json

from dotenv import load_dotenv
from gllm_inference.em_invoker import OpenAIEMInvoker
from gllm_misc.router import AurelioSemanticRouter
from gllm_misc.router.aurelio_semantic_router.encoders import EMInvokerEncoder

load_dotenv()

# Create encoder for semantic router
encoder = EMInvokerEncoder(
    em_invoker = OpenAIEMInvoker(
        api_key=os.environ["OPENAI_API_KEY"],
        model_name="text-embedding-3-small",
    ),
    score_threshold = 0.3,
)

# Load route examples from json file
with open("route_examples.json", "r", encoding="utf-8") as f:
    route_examples = json.load(f)

semantic_router = AurelioSemanticRouter(
    default_route = "general",
    valid_routes = set({"knowledge_base", "general"}),
    encoder = encoder,
    routes = route_examples,
)
