import asyncio
from gllm_pipeline.pipeline.pipeline import Pipeline
from gllm_pipeline.pipeline.states import RAGState
from gllm_pipeline.steps import bundle, step, switch

from modules.repacker import repacker
from modules.response_synthesizer import response_synthesizer
from modules.retriever import retriever
from modules.semantic_router import semantic_router
from modules.handlers import general_query_handler

# Same as your first RAG pipeline
retriever_step = step(
    retriever,
    {"query": "user_query"},
    "chunks",
    {"top_k": "top_k"},
)

repacker_step = step(
    repacker,
    {"chunks": "chunks"},  # input variables
    "context",  # output variable
)

bundler_step = bundle(
    ["context"],
    "response_synthesis_bundle",
)

response_synthesizer_step = step(
    response_synthesizer,
    {"query": "user_query", "state_variables": "response_synthesis_bundle"},
    "response",
)

# Add general query step
general_query_step = step(
    general_query_handler,
    {"query": "user_query"},
    "response",
)

# Implement switch step to wrap the pipeline with semantic router as condition
conditional_step = switch(
    condition = semantic_router,
    branches = {
        "knowledge_base": [retriever_step, repacker_step, bundler_step, response_synthesizer_step],
        "general": general_query_step,
    },
    default = general_query_step,
    input_state_map = {"source": "user_query"},
    output_state = "response",
)

# Define state type for the pipeline, extend RAGState
class RouterState(RAGState):
    route: str
    source: str

# Initialize the pipeline with the conditional step and the state type
e2e_pipeline_with_semantic_router = Pipeline(steps=[conditional_step], state_type=RouterState)

# Configure the state and config for direct pipeline invocation
state = {
    "user_query": "Give me nocturnal creatures from the dataset",  # Replace with your actual query
    # "user_query": "What is the capital of France?",
}

config = {
    "top_k": 5,
    "debug": True,  # Set to True to look at the pipeline execution flow
}

result = asyncio.run(e2e_pipeline_with_semantic_router.invoke(state, config))
print(f"Pipeline result: {result['response']}")
